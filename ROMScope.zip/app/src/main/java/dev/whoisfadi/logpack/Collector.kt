package dev.whoisfadi.logpack

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.DropBoxManager
import android.os.Environment
import android.os.StatFs
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

const val AUTHOR = "@whoisfadi"
const val APP_VERSION = "1.0.0"
const val PKG = "dev.whoisfadi.logpack"
const val READ_LOGS = "android.permission.READ_LOGS"

enum class State { OK, LIMITED, FAILED }

data class Item(val name: String, val state: State, val note: String)

data class Report(val file: File, val items: List<Item>, val summary: String)

data class Options(val mask: Boolean, val tryRoot: Boolean, val userNote: String)

fun hasReadLogs(ctx: Context): Boolean =
    ctx.checkSelfPermission(READ_LOGS) == PackageManager.PERMISSION_GRANTED

object Masker {
    private val propLine = Regex("""^\[([^\]]+)\]: \[(.*)\]$""")
    private val sensitiveKey = Regex("""(?i)(serial|imei|meid|macaddr|bdaddr|bt_addr|wifi.*address|android_id)""")
    private val digits15 = Regex("""\b\d{15}\b""")
    private val mac = Regex("""\b(?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}\b""")
    private val email = Regex("""[A-Za-z0-9._%+-]+@(?![0-9])[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}""")
    private val fileExt = setOf("so", "rc", "xml", "apk", "jar", "odex", "vdex", "art", "oat", "img", "txt", "json", "bin", "conf", "cfg", "ko", "dex", "idc", "kl", "kcm", "policy", "cil", "hal")
    private val ssid = Regex("""(?i)(ssid[=:]\s*)("[^"]*"|[^\s,]+)""")

    fun apply(text: String): String {
        val sb = StringBuilder(text.length)
        for (line in text.lineSequence()) {
            var l = line
            val m = propLine.find(l)
            if (m != null && sensitiveKey.containsMatchIn(m.groupValues[1])) {
                l = "[" + m.groupValues[1] + "]: [<MASKED>]"
            } else {
                l = digits15.replace(l, "<MASKED_15_DIGITS>")
                l = mac.replace(l, "XX:XX:XX:XX:XX:XX")
                l = email.replace(l) { m ->
                    if (m.value.substringAfterLast('.').lowercase() in fileExt) m.value else "<EMAIL>"
                }
                l = ssid.replace(l, "\$1\"<SSID>\"")
            }
            sb.append(l).append('\n')
        }
        return sb.toString()
    }
}

object Collector {
    data class Exec(val out: String, val code: Int)

    private val DROP_TAGS = listOf(
        "SYSTEM_LAST_KMSG", "SYSTEM_BOOT", "SYSTEM_RESTART", "SYSTEM_TOMBSTONE",
        "system_server_crash", "system_server_anr", "system_server_watchdog",
        "system_app_crash", "system_app_anr", "data_app_crash", "data_app_anr",
        "SYSTEM_AUDIT", "SYSTEM_RECOVERY_LOG"
    )

    fun exec(cmd: Array<String>, maxLines: Int = 100000, timeoutMs: Long = 20000): Exec? {
        return try {
            val p = ProcessBuilder(*cmd).redirectErrorStream(true).start()
            val killer = Thread {
                try {
                    Thread.sleep(timeoutMs)
                    p.destroy()
                } catch (e: InterruptedException) {
                }
            }
            killer.isDaemon = true
            killer.start()
            val dq = ArrayDeque<String>()
            p.inputStream.bufferedReader().useLines { seq ->
                for (l in seq) {
                    dq.addLast(l)
                    if (dq.size > maxLines) dq.removeFirst()
                }
            }
            killer.interrupt()
            val code = try {
                p.waitFor()
            } catch (e: InterruptedException) {
                -1
            }
            Exec(dq.joinToString("\n"), code)
        } catch (e: Exception) {
            null
        }
    }

    private fun isError(s: String?): Boolean {
        if (s == null || s.isBlank()) return true
        val short = s.lines().size <= 3
        return short && (s.contains("not permitted", true) || s.contains("permission denied", true) ||
            s.contains("not found", true) || s.contains("no such file", true) || s.contains("inaccessible", true))
    }

    private fun propValue(props: String, key: String): String? =
        Regex("""\[${Regex.escape(key)}\]: \[(.*)\]""").find(props)?.groupValues?.get(1)

    private fun readCapped(f: File, cap: Int = 2_000_000): String? =
        try {
            f.readText().take(cap)
        } catch (e: Exception) {
            null
        }

    private fun collectDropbox(ctx: Context): Pair<List<Pair<String, String>>, String?> {
        val dbm = ctx.getSystemService(Context.DROPBOX_SERVICE) as? DropBoxManager
            ?: return Pair(emptyList(), "DropBox service not available")
        val out = ArrayList<Pair<String, String>>()
        try {
            for (tag in DROP_TAGS) {
                val times = ArrayList<Long>()
                var since = 0L
                while (times.size < 500) {
                    val e = dbm.getNextEntry(tag, since) ?: break
                    val t = e.timeMillis
                    e.close()
                    times.add(t)
                    since = t
                }
                for (t in times.takeLast(10)) {
                    val e = dbm.getNextEntry(tag, t - 1) ?: continue
                    val text = try {
                        e.getText(64 * 1024)
                    } finally {
                        e.close()
                    }
                    if (text != null) out.add(Pair("${tag}_$t.txt", text))
                }
            }
        } catch (se: SecurityException) {
            return Pair(out, "Denied by system: " + (se.message ?: "SecurityException").take(100))
        }
        return Pair(out, null)
    }

    private fun dropboxViaRoot(): List<Pair<String, String>> {
        val script = "cd /data/system/dropbox 2>/dev/null || exit 1; " +
            "for f in \$(ls -t | head -40); do echo \"=====FILE \$f\"; " +
            "case \"\$f\" in *.gz) zcat \"\$f\" 2>/dev/null | head -c 65536;; *) head -c 65536 \"\$f\";; esac; echo; done"
        val r = exec(arrayOf("su", "-c", script), 200000, 30000)?.out ?: return emptyList()
        val out = ArrayList<Pair<String, String>>()
        var name: String? = null
        val sb = StringBuilder()
        fun flush() {
            val n = name
            if (n != null && sb.isNotBlank() && !n.contains("PROTO") && !n.endsWith(".dat")) {
                val clean = n.removeSuffix(".gz").removeSuffix(".txt").replace('@', '_')
                out.add(Pair("$clean.txt", sb.toString()))
            }
            sb.setLength(0)
        }
        for (line in r.lineSequence()) {
            if (line.startsWith("=====FILE ")) {
                flush()
                name = line.removePrefix("=====FILE ").trim()
            } else {
                sb.appendLine(line)
            }
        }
        flush()
        return out
    }

    private fun batteryText(ctx: Context): String {
        val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return "Battery info not available"
        val status = when (b.getIntExtra(BatteryManager.EXTRA_STATUS, -1)) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "charging"
            BatteryManager.BATTERY_STATUS_DISCHARGING -> "discharging"
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "not charging"
            BatteryManager.BATTERY_STATUS_FULL -> "full"
            else -> "unknown"
        }
        val health = when (b.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "good"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "overheat"
            BatteryManager.BATTERY_HEALTH_DEAD -> "dead"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "over voltage"
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "failure"
            BatteryManager.BATTERY_HEALTH_COLD -> "cold"
            else -> "unknown"
        }
        val sb = StringBuilder()
        sb.appendLine("Level: ${b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)} / ${b.getIntExtra(BatteryManager.EXTRA_SCALE, -1)}")
        sb.appendLine("Temperature: ${b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0} C")
        sb.appendLine("Voltage: ${b.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)} mV")
        sb.appendLine("Status: $status")
        sb.appendLine("Health: $health")
        sb.appendLine("Plugged: ${b.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)}")
        sb.appendLine("Technology: ${b.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY)}")
        return sb.toString()
    }

    private val avcRe = Regex("""avc:\s+denied""")

    private fun countAvc(text: String?): Int =
        text?.lineSequence()?.count { avcRe.containsMatchIn(it) } ?: 0

    private fun count(text: String?, needle: String): Int =
        text?.lineSequence()?.count { it.contains(needle) } ?: 0

    private fun samples(text: String?, needle: String, max: Int = 5): List<String> {
        if (text == null) return emptyList()
        val lines = text.lines()
        val out = ArrayList<String>()
        for (i in lines.indices) {
            if (lines[i].contains(needle)) {
                val next = lines.getOrNull(i + 1)?.trim() ?: ""
                out.add(lines[i].trim() + "  |  " + next)
                if (out.size >= max) break
            }
        }
        return out
    }

    fun collect(ctx: Context, opt: Options, progress: (String) -> Unit): Report {
        val items = ArrayList<Item>()
        val files = LinkedHashMap<String, String>()
        fun put(path: String, text: String) {
            files[path] = if (opt.mask) Masker.apply(text) else text
        }

        // Device and ROM info
        progress("Device and ROM info...")
        val build = buildString {
            appendLine("Brand: ${Build.BRAND}")
            appendLine("Manufacturer: ${Build.MANUFACTURER}")
            appendLine("Model: ${Build.MODEL}")
            appendLine("Device: ${Build.DEVICE}")
            appendLine("Product: ${Build.PRODUCT}")
            appendLine("Board: ${Build.BOARD}")
            appendLine("Hardware: ${Build.HARDWARE}")
            appendLine("Android: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
            appendLine("Build display: ${Build.DISPLAY}")
            appendLine("Incremental: ${Build.VERSION.INCREMENTAL}")
            appendLine("Type/Tags: ${Build.TYPE} / ${Build.TAGS}")
            appendLine("Fingerprint: ${Build.FINGERPRINT}")
            appendLine("Security patch: ${Build.VERSION.SECURITY_PATCH}")
            appendLine("Bootloader: ${Build.BOOTLOADER}")
            appendLine("ABIs: ${Build.SUPPORTED_ABIS.joinToString(", ")}")
        }
        put("device/build.txt", build)
        items.add(Item("Device and ROM info", State.OK, ""))

        progress("System properties...")
        val props = exec(arrayOf("getprop"))?.out ?: ""
        if (props.isBlank()) {
            items.add(Item("System properties (getprop)", State.FAILED, "getprop returned nothing"))
        } else {
            put("device/props.txt", props)
            items.add(Item("System properties (getprop)", State.OK, props.lines().size.toString() + " properties"))
        }

        progress("Kernel info...")
        val kernel = buildString {
            appendLine("os.version: ${System.getProperty("os.version")}")
            appendLine("/proc/version: " + (readCapped(File("/proc/version"))?.trim() ?: "not readable"))
            appendLine("uname -a: " + (exec(arrayOf("uname", "-a"))?.out?.trim() ?: "not available"))
        }
        put("device/kernel.txt", kernel)
        items.add(Item("Kernel version", State.OK, ""))

        progress("SELinux mode...")
        var selinux = exec(arrayOf("getenforce"))?.out?.trim() ?: ""
        if (selinux.isBlank() || selinux.length > 20) {
            selinux = when (readCapped(File("/sys/fs/selinux/enforce"))?.trim()) {
                "1" -> "Enforcing"
                "0" -> "Permissive"
                else -> "unknown"
            }
        }
        put("device/selinux.txt", selinux)
        items.add(Item("SELinux mode", if (selinux == "unknown") State.LIMITED else State.OK, selinux))

        progress("Battery, memory, storage...")
        put("device/battery.txt", batteryText(ctx))
        val mem = readCapped(File("/proc/meminfo")) ?: "not readable"
        val st = try {
            val s = StatFs(Environment.getDataDirectory().path)
            "Data partition: free ${s.availableBytes / 1048576} MB of ${s.totalBytes / 1048576} MB"
        } catch (e: Exception) {
            "Storage info not available"
        }
        put("device/memory_storage.txt", st + "\n\n" + mem)
        items.add(Item("Battery, memory, storage", State.OK, ""))

        progress("Thermal zones...")
        val th = StringBuilder()
        var zones = 0
        for (i in 0..49) {
            val d = File("/sys/class/thermal/thermal_zone$i")
            if (!d.exists()) continue
            val type = try {
                File(d, "type").readText().trim()
            } catch (e: Exception) {
                continue
            }
            val temp = try {
                File(d, "temp").readText().trim()
            } catch (e: Exception) {
                "?"
            }
            th.appendLine("zone$i $type $temp")
            zones++
        }
        if (zones > 0) {
            put("device/thermal.txt", th.toString())
            items.add(Item("Thermal zones", State.OK, "$zones zones"))
        } else {
            items.add(Item("Thermal zones", State.LIMITED, "not readable by apps on this device"))
        }

        // Logcat
        progress("Logcat (can take a few seconds)...")
        val granted = hasReadLogs(ctx)
        var lc = exec(arrayOf("logcat", "-b", "all", "-t", "100000", "-v", "threadtime"), 100000, 30000)?.out
        var lcNote = ""
        var lcState = State.OK
        if (!granted) {
            if (opt.tryRoot) {
                val r = exec(arrayOf("su", "-c", "logcat -b all -t 100000 -v threadtime"), 100000, 30000)?.out
                if (!isError(r)) {
                    lc = r
                    lcNote = "via root"
                } else {
                    lcState = State.LIMITED
                    lcNote = "only this app's own logs (grant READ_LOGS)"
                }
            } else {
                lcState = State.LIMITED
                lcNote = "only this app's own logs (grant READ_LOGS)"
            }
        }
        if (lc.isNullOrBlank()) {
            items.add(Item("Logcat (all buffers)", State.FAILED, "no output"))
        } else {
            put("logs/logcat.txt", lc)
            items.add(Item("Logcat (all buffers)", lcState, if (lcNote.isEmpty()) lc.lines().size.toString() + " lines" else lcNote))
        }

        // dmesg
        progress("Kernel log (dmesg)...")
        var dm = exec(arrayOf("dmesg"), 100000, 20000)?.out
        var dmNote = ""
        if (isError(dm) && opt.tryRoot) {
            dm = exec(arrayOf("su", "-c", "dmesg"), 100000, 20000)?.out
            dmNote = "via root"
        }
        if (isError(dm)) {
            items.add(Item("Kernel log (dmesg)", State.LIMITED, "needs root on this device"))
        } else {
            put("logs/dmesg.txt", dm!!)
            items.add(Item("Kernel log (dmesg)", State.OK, dmNote))
        }

        // pstore
        progress("pstore / ramoops...")
        val pdir = File("/sys/fs/pstore")
        val plist = try {
            pdir.listFiles()
        } catch (e: Exception) {
            null
        }
        var pstoreDone = false
        if (plist != null && plist.isNotEmpty()) {
            var n = 0
            for (f in plist) {
                if (f.name.startsWith("pmsg")) continue
                val t = readCapped(f)
                if (t != null) {
                    put("logs/pstore/${f.name}.txt", t)
                    n++
                }
            }
            if (n > 0) {
                items.add(Item("pstore (previous boot crash log)", State.OK, "$n files"))
                pstoreDone = true
            }
        }
        if (!pstoreDone && opt.tryRoot) {
            val r = exec(arrayOf("su", "-c", "tail -n +1 /sys/fs/pstore/*"), 50000, 20000)?.out
            if (!isError(r)) {
                put("logs/pstore/pstore_root.txt", r!!)
                items.add(Item("pstore (previous boot crash log)", State.OK, "via root"))
                pstoreDone = true
            }
        }
        if (!pstoreDone) {
            val why = if (!pdir.exists()) "not available on this kernel"
            else "empty (no crash saved) or needs root"
            items.add(Item("pstore (previous boot crash log)", State.LIMITED, why))
        }

        // last_kmsg
        progress("last_kmsg...")
        var lk = readCapped(File("/proc/last_kmsg"))
        var lkNote = ""
        if (isError(lk) && opt.tryRoot) {
            lk = exec(arrayOf("su", "-c", "cat /proc/last_kmsg"), 50000, 15000)?.out
            lkNote = "via root"
        }
        if (isError(lk)) {
            items.add(Item("last_kmsg", State.LIMITED, "not available (common on newer kernels, see DropBox)"))
        } else {
            put("logs/last_kmsg.txt", lk!!)
            items.add(Item("last_kmsg", State.OK, lkNote))
        }

        // DropBox
        progress("DropBox (crashes, ANRs, tombstones)...")
        val (drop0, dropErr0) = try {
            collectDropbox(ctx)
        } catch (e: Exception) {
            Pair(emptyList<Pair<String, String>>(), "failed: " + (e.message ?: "unknown"))
        }
        var drop = drop0
        var dropErr = dropErr0
        var dropNote = ""
        if (drop.isEmpty() && opt.tryRoot) {
            val d = dropboxViaRoot()
            if (d.isNotEmpty()) {
                drop = d
                dropErr = null
                dropNote = " (via root)"
            }
        }
        for ((name, text) in drop) put("logs/dropbox/$name", text)
        if (dropErr != null) {
            items.add(Item("DropBox (crashes, ANRs, last_kmsg)", State.LIMITED, dropErr + if (opt.tryRoot) "" else " - try the root switch"))
        } else {
            items.add(Item("DropBox (crashes, ANRs, last_kmsg)", State.OK, "${drop.size} entries$dropNote"))
        }

        // Summary
        progress("Building zip...")
        val now = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        val logsText = files.filterKeys { it.startsWith("logs/") }.values
        val lcText = files["logs/logcat.txt"]
        val summary = buildString {
            appendLine("LogsPack Bug Report Summary")
            appendLine("by $AUTHOR - app v$APP_VERSION - generated $now")
            appendLine()
            appendLine("== What happened (from the user) ==")
            appendLine(if (opt.userNote.isBlank()) "(not provided)" else opt.userNote.trim())
            appendLine()
            appendLine("== Device ==")
            appendLine("Model: ${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE})")
            appendLine("ROM build: ${Build.DISPLAY}")
            appendLine("Android: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT}), patch ${Build.VERSION.SECURITY_PATCH}")
            appendLine("Fingerprint: ${Build.FINGERPRINT}")
            appendLine("Kernel: ${System.getProperty("os.version")}")
            appendLine("SELinux: $selinux")
            for (k in listOf("ro.boot.bootreason", "sys.boot.reason", "sys.boot.reason.last", "persist.sys.boot.reason")) {
                val v = propValue(props, k)
                if (v != null) appendLine("$k: $v")
            }
            appendLine()
            appendLine("== Collection status ==")
            for (i in items) {
                val tag = when (i.state) {
                    State.OK -> "[OK]"
                    State.LIMITED -> "[LIMITED]"
                    State.FAILED -> "[FAILED]"
                }
                appendLine("$tag ${i.name}" + if (i.note.isNotEmpty()) " - ${i.note}" else "")
            }
            appendLine()
            appendLine("== Quick scan ==")
            appendLine("FATAL EXCEPTION in logcat: ${count(lcText, "FATAL EXCEPTION")}")
            appendLine("ANR in logcat: ${count(lcText, "ANR in")}")
            appendLine("Watchdog mentions in logcat: ${count(lcText, "Watchdog")}")
            appendLine("Kernel panic mentions (all logs): ${logsText.sumOf { count(it, "Kernel panic") }}")
            appendLine("SELinux denials (all logs): ${logsText.sumOf { countAvc(it) }}")
            val dropFiles = files.filterKeys { it.startsWith("logs/dropbox/") }
            if (dropFiles.isNotEmpty()) {
                val tomb = dropFiles.keys.count { it.contains("TOMBSTONE") }
                val anr = dropFiles.keys.count { it.contains("anr", true) }
                val crash = dropFiles.keys.count { it.contains("crash", true) }
                appendLine("DropBox: $tomb tombstones, $anr ANRs, $crash app/system crashes")
                val procs = LinkedHashSet<String>()
                for ((k, v) in dropFiles) {
                    if (k.contains("anr", true) || k.contains("crash", true)) {
                        val line = v.lineSequence().firstOrNull { it.startsWith("Process:") }
                        if (line != null) procs.add(line.removePrefix("Process:").trim())
                    }
                }
                if (procs.isNotEmpty()) appendLine("Processes in ANRs/crashes: " + procs.take(10).joinToString(", "))
            }
            val fe = samples(lcText, "FATAL EXCEPTION")
            if (fe.isNotEmpty()) {
                appendLine()
                appendLine("First fatal exceptions:")
                for (s in fe) appendLine("  $s")
            }
            val kp = logsText.flatMap { samples(it, "Kernel panic", 2) }.take(3)
            if (kp.isNotEmpty()) {
                appendLine()
                appendLine("Kernel panic lines:")
                for (s in kp) appendLine("  $s")
            }
            appendLine()
            appendLine("Note: " + if (opt.mask) "sensitive data masking was ON (best effort, review before posting publicly)."
            else "masking was OFF, this report may contain personal data.")
        }

        val dir = File(ctx.cacheDir, "reports")
        dir.mkdirs()
        dir.listFiles()?.forEach { it.delete() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val zip = File(dir, "logpack_$stamp.zip")
        ZipOutputStream(zip.outputStream().buffered()).use { z ->
            z.putNextEntry(ZipEntry("summary.txt"))
            z.write(summary.toByteArray())
            z.closeEntry()
            for ((n, t) in files) {
                z.putNextEntry(ZipEntry(n))
                z.write(t.toByteArray())
                z.closeEntry()
            }
        }
        return Report(zip, items, summary)
    }
}
