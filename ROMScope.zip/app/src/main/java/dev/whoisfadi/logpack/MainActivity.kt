package dev.whoisfadi.logpack

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LogPackTheme { LogPackApp() } }
    }
}

@Composable
fun LogPackTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = if (Build.VERSION.SDK_INT >= 31) {
        if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else {
        if (dark) darkColorScheme() else lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

fun shareZip(ctx: Context, file: File) {
    try {
        val uri = FileProvider.getUriForFile(ctx, "$PKG.fileprovider", file)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "application/zip"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "Share report"))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Could not share", Toast.LENGTH_SHORT).show()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LogPackApp() {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    var granted by remember { mutableStateOf(hasReadLogs(ctx)) }
    var mask by remember { mutableStateOf(true) }
    var tryRoot by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    var running by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf("") }
    var report by remember { mutableStateOf<Report?>(null) }

    val grantCmd = "adb shell pm grant $PKG $READ_LOGS"

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        val r = report
        if (uri != null && r != null) {
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { out ->
                    r.file.inputStream().use { it.copyTo(out) }
                }
                Toast.makeText(ctx, "Saved", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(ctx, "Could not save", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("LogPack", fontWeight = FontWeight.Bold) }) }
    ) { pad ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("ROM BUG REPORT COLLECTOR", style = MaterialTheme.typography.labelMedium)
                    Text("Collect logs. Share one zip.", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Logcat, kernel logs, previous-boot crash data, ROM info, all in one masked zip.")
                    Text("Developed by $AUTHOR", fontWeight = FontWeight.SemiBold)
                }
            }

            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        if (granted) "✓ Log access granted" else "⚠ Log access not granted",
                        fontWeight = FontWeight.Bold,
                        color = if (granted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                    )
                    if (!granted) {
                        Text(
                            "Without it, only this app's own logs can be read (no system logcat, no DropBox crash data). " +
                                "Run this once from adb (PC, or Termux with wireless debugging), or use root:",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(grantCmd, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                clipboard.setText(AnnotatedString(grantCmd))
                                Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
                            }) { Text("Copy command") }
                            OutlinedButton(onClick = {
                                scope.launch {
                                    withContext(Dispatchers.IO) {
                                        Collector.exec(arrayOf("su", "-c", "pm grant $PKG $READ_LOGS"), 50, 15000)
                                    }
                                    granted = hasReadLogs(ctx)
                                    Toast.makeText(ctx, if (granted) "Granted" else "Root grant failed", Toast.LENGTH_SHORT).show()
                                }
                            }) { Text("Grant via root") }
                        }
                        TextButton(onClick = { granted = hasReadLogs(ctx) }) { Text("Re-check") }
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Mask sensitive data", fontWeight = FontWeight.SemiBold)
                    Text("IMEI-like numbers, serials, MAC, email, Wi-Fi name", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = mask, onCheckedChange = { mask = it })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Try root (su)", fontWeight = FontWeight.SemiBold)
                    Text("For dmesg, pstore and last_kmsg if available", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = tryRoot, onCheckedChange = { tryRoot = it })
            }

            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("What happened? (optional)") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    scope.launch {
                        granted = hasReadLogs(ctx)
                        running = true
                        report = null
                        val r = withContext(Dispatchers.IO) {
                            try {
                                Collector.collect(ctx, Options(mask, tryRoot, note)) { p -> progress = p }
                            } catch (e: Exception) {
                                null
                            }
                        }
                        running = false
                        if (r == null) Toast.makeText(ctx, "Collection failed", Toast.LENGTH_LONG).show()
                        report = r
                    }
                },
                enabled = !running,
                modifier = Modifier.fillMaxWidth()
            ) { Text("Collect logs") }

            if (running) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp))
                    Text(progress)
                }
            }

            val r = report
            if (r != null) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Report ready (${r.file.length() / 1024} KB)", fontWeight = FontWeight.Bold)
                        for (item in r.items) {
                            val sym = when (item.state) {
                                State.OK -> "✓"
                                State.LIMITED -> "⚠"
                                State.FAILED -> "✗"
                            }
                            val col = when (item.state) {
                                State.OK -> MaterialTheme.colorScheme.primary
                                State.LIMITED -> MaterialTheme.colorScheme.tertiary
                                State.FAILED -> MaterialTheme.colorScheme.error
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(sym, color = col, fontWeight = FontWeight.Bold)
                                Column {
                                    Text(item.name, fontWeight = FontWeight.SemiBold)
                                    if (item.note.isNotEmpty()) {
                                        Text(item.note, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { shareZip(ctx, r.file) }) { Text("Share zip") }
                    OutlinedButton(onClick = { saver.launch(r.file.name) }) { Text("Save zip") }
                }
            }

            Text(
                "Review the zip before posting it publicly. Masking is best effort and cannot catch everything.",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
