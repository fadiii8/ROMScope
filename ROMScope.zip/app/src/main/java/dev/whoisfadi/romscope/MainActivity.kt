package dev.whoisfadi.romscope

import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class Screen(val title: String) {
    HOME("ROMScope"),
    ANALYZER("Build.prop Analyzer"),
    COMPARE("ROM Comparison"),
    REPORT("Analysis Reports"),
    DEVICE("Device Information")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ROMScopeTheme { ROMScopeApp() }
        }
    }
}

@Composable
fun ROMScopeTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = if (Build.VERSION.SDK_INT >= 31) {
        if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else {
        if (dark) darkColorScheme() else lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

fun loadProp(ctx: Context, uri: Uri): PropFile? {
    try {
        var name = "file"
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && c.moveToFirst()) name = c.getString(idx)
        }
        val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            ?: return null
        return PropFile(name, PropParser.parse(text))
    } catch (e: Exception) {
        return null
    }
}

@Composable
fun rememberPicker(onLoaded: (PropFile) -> Unit): () -> Unit {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val f = loadProp(ctx, uri)
            if (f != null) onLoaded(f)
            else Toast.makeText(ctx, "Could not read this file", Toast.LENGTH_SHORT).show()
        }
    }
    return { launcher.launch(arrayOf("*/*")) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ROMScopeApp() {
    var screen by remember { mutableStateOf(Screen.HOME) }
    var fileA by remember { mutableStateOf<PropFile?>(null) }
    var fileB by remember { mutableStateOf<PropFile?>(null) }

    BackHandler(enabled = screen != Screen.HOME) { screen = Screen.HOME }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(screen.title, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    if (screen != Screen.HOME) {
                        TextButton(onClick = { screen = Screen.HOME }) { Text("←") }
                    }
                }
            )
        }
    ) { pad ->
        when (screen) {
            Screen.HOME -> HomeScreen(pad) { screen = it }
            Screen.ANALYZER -> AnalyzerScreen(pad, fileA) { fileA = it }
            Screen.COMPARE -> CompareScreen(pad, fileA, fileB, { fileA = it }, { fileB = it })
            Screen.REPORT -> ReportScreen(pad, fileA, fileB)
            Screen.DEVICE -> DeviceScreen(pad)
        }
    }
}

@Composable
fun HomeScreen(pad: PaddingValues, onOpen: (Screen) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(pad)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.primaryContainer,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("ANDROID ROM TOOLKIT", style = MaterialTheme.typography.labelMedium)
                Text(
                    "Understand your ROM.",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Text("Analyze, compare and explore Android ROM properties.")
                Text("Developed by @whoisfadi", fontWeight = FontWeight.SemiBold)
            }
        }
        Text("Tools", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FeatureCard("🔍", "Build.prop Analyzer", "Inspect Android build properties") { onOpen(Screen.ANALYZER) }
        FeatureCard("⚖️", "ROM Comparison", "Compare two build.prop files") { onOpen(Screen.COMPARE) }
        FeatureCard("📄", "Analysis Reports", "View and export analysis reports") { onOpen(Screen.REPORT) }
        FeatureCard("📱", "Device Information", "Explore your device information") { onOpen(Screen.DEVICE) }

        Surface(
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("ROMScope v1.0.0", fontWeight = FontWeight.Bold)
                Text(
                    "Read-only analysis. build.prop alone cannot guarantee a ROM will boot or be compatible.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "Made by @whoisfadi",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
fun FeatureCard(icon: String, title: String, description: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            modifier = Modifier.padding(18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(icon, style = MaterialTheme.typography.headlineMedium)
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text("›", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Column(Modifier.fillMaxWidth()) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
        SelectionContainer {
            Text(
                value,
                style = MaterialTheme.typography.bodyMedium,
                color = if (value == "Not found") MaterialTheme.colorScheme.error
                else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun AnalyzerScreen(pad: PaddingValues, file: PropFile?, onLoaded: (PropFile) -> Unit) {
    val pick = rememberPicker(onLoaded)
    var query by remember { mutableStateOf("") }
    val filtered = remember(file, query) {
        file?.props?.entries?.filter {
            query.isBlank() || it.key.contains(query, true) || it.value.contains(query, true)
        } ?: emptyList()
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(pad),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Button(onClick = pick) { Text("Select build.prop") } }
        if (file == null) {
            item { Text("No file selected yet.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        } else {
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(file.name, fontWeight = FontWeight.Bold)
                        Text("Total properties: ${file.props.size}")
                        for ((label, key) in IMPORTANT) {
                            InfoRow(label, file.find(key) ?: "Not found")
                        }
                    }
                }
            }
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("Search all properties") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item { Text("${filtered.size} properties", style = MaterialTheme.typography.labelMedium) }
            items(filtered) { e ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text(e.key, fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(e.value, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun CompareScreen(
    pad: PaddingValues,
    a: PropFile?,
    b: PropFile?,
    onA: (PropFile) -> Unit,
    onB: (PropFile) -> Unit
) {
    val pickA = rememberPicker(onA)
    val pickB = rememberPicker(onB)
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf<Status?>(null) }
    val rows = remember(a, b) {
        if (a != null && b != null) compareProps(a.props, b.props) else emptyList()
    }
    val shown = remember(rows, query, filter) {
        rows.filter {
            (filter == null || it.status == filter) &&
                (query.isBlank() || it.key.contains(query, true))
        }
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(pad),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = pickA) { Text("Select ROM A") }
                Button(onClick = pickB) { Text("Select ROM B") }
            }
        }
        item { Text("ROM A: ${a?.name ?: "not selected"}") }
        item { Text("ROM B: ${b?.name ?: "not selected"}") }
        if (a != null && b != null) {
            item {
                Text(
                    Status.values().joinToString("  •  ") { s -> "${s.label}: ${rows.count { it.status == s }}" },
                    style = MaterialTheme.typography.labelMedium
                )
            }
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = filter == null, onClick = { filter = null }, label = { Text("All") })
                    for (s in Status.values()) {
                        FilterChip(selected = filter == s, onClick = { filter = s }, label = { Text(s.label) })
                    }
                }
            }
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("Search property key") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            items(shown) { r ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(r.key, fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(r.status.label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        Text("A: ${r.a ?: "-"}", fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        Text("B: ${r.b ?: "-"}", fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                    }
                }
            }
        } else {
            item { Text("Select both files to compare.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}

@Composable
fun ReportScreen(pad: PaddingValues, a: PropFile?, b: PropFile?) {
    val ctx = LocalContext.current
    val report = remember(a, b) { buildReport(a, b) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(report.toByteArray()) }
                Toast.makeText(ctx, "Report saved", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(ctx, "Could not save report", Toast.LENGTH_SHORT).show()
            }
        }
    }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(pad)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (a == null && b == null) {
            Text(
                "Load a file in Analyzer or Comparison first, then come back here.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            OutlinedButton(onClick = { launcher.launch("romscope_report.txt") }) { Text("Export as .txt") }
            Text("Preview (first 150 lines; export has everything)", style = MaterialTheme.typography.labelMedium)
            SelectionContainer {
                Text(
                    report.lineSequence().take(150).joinToString("\n"),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    modifier = Modifier.verticalScroll(rememberScrollState())
                )
            }
        }
    }
}

@Composable
fun DeviceScreen(pad: PaddingValues) {
    val items = listOf(
        "Device" to Build.DEVICE,
        "Model" to Build.MODEL,
        "Manufacturer" to Build.MANUFACTURER,
        "Brand" to Build.BRAND,
        "Android release" to Build.VERSION.RELEASE,
        "SDK version" to Build.VERSION.SDK_INT.toString(),
        "Build type" to Build.TYPE,
        "Security patch" to (Build.VERSION.SECURITY_PATCH ?: "Not found"),
        "Build fingerprint" to Build.FINGERPRINT
    )
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(pad)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                for ((l, v) in items) InfoRow(l, v)
            }
        }
        Text(
            "No IMEI, phone number or serial number is ever read.",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
