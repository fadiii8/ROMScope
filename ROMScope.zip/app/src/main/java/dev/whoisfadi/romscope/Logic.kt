package dev.whoisfadi.romscope

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class PropFile(val name: String, val props: Map<String, String>)

enum class Status(val label: String) {
    SAME("Same"),
    CHANGED("Changed"),
    ONLY_A("Only in A"),
    ONLY_B("Only in B")
}

data class DiffRow(val key: String, val a: String?, val b: String?, val status: Status)

val IMPORTANT = listOf(
    "Device codename" to "ro.product.device",
    "Model" to "ro.product.model",
    "Brand" to "ro.product.brand",
    "Manufacturer" to "ro.product.manufacturer",
    "Android version" to "ro.build.version.release",
    "SDK version" to "ro.build.version.sdk",
    "Build type" to "ro.build.type",
    "Build fingerprint" to "ro.build.fingerprint",
    "Security patch" to "ro.build.version.security_patch"
)

object PropParser {
    fun parse(text: String): Map<String, String> {
        val map = LinkedHashMap<String, String>()
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) continue
            val i = line.indexOf('=')
            if (i <= 0) continue
            map[line.substring(0, i).trim()] = line.substring(i + 1).trim()
        }
        return map
    }
}

fun PropFile.find(key: String): String? {
    props[key]?.let { return it }
    if (key.startsWith("ro.product.")) {
        val tail = key.removePrefix("ro.product.")
        for (p in listOf("system", "vendor", "odm", "product", "system_ext")) {
            props["ro.product.$p.$tail"]?.let { return it }
        }
    }
    if (key.startsWith("ro.build.") && !key.startsWith("ro.build.version.")) {
        props["ro.system.build." + key.removePrefix("ro.build.")]?.let { return it }
    }
    return null
}

fun compareProps(a: Map<String, String>, b: Map<String, String>): List<DiffRow> {
    val keys = (a.keys + b.keys).toSortedSet()
    return keys.map { k ->
        val va = a[k]
        val vb = b[k]
        val st = when {
            va == null -> Status.ONLY_B
            vb == null -> Status.ONLY_A
            va == vb -> Status.SAME
            else -> Status.CHANGED
        }
        DiffRow(k, va, vb, st)
    }
}

fun buildReport(a: PropFile?, b: PropFile?): String {
    val sb = StringBuilder()
    val now = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
    sb.appendLine("ROMScope Analysis Report")
    sb.appendLine("by @whoisfadi")
    sb.appendLine("Generated: $now")
    sb.appendLine()
    sb.appendLine("Note: build.prop analysis cannot guarantee that a ROM will boot or be compatible.")

    fun section(title: String, f: PropFile) {
        sb.appendLine()
        sb.appendLine("=== $title: ${f.name} ===")
        sb.appendLine("Total properties: ${f.props.size}")
        val missing = ArrayList<String>()
        for ((label, key) in IMPORTANT) {
            val v = f.find(key)
            if (v == null) missing.add(key)
            sb.appendLine("$label: ${v ?: "Not found"}")
        }
        sb.appendLine("Missing important properties: " + if (missing.isEmpty()) "none" else missing.joinToString(", "))
    }
    if (a != null) section("ROM A", a)
    if (b != null) section("ROM B", b)

    if (a != null && b != null) {
        val rows = compareProps(a.props, b.props)
        sb.appendLine()
        sb.appendLine("=== Comparison ===")
        for (s in Status.values()) {
            sb.appendLine("${s.label}: ${rows.count { it.status == s }}")
        }
        for (s in listOf(Status.CHANGED, Status.ONLY_A, Status.ONLY_B)) {
            sb.appendLine()
            sb.appendLine("--- ${s.label} ---")
            for (r in rows.filter { it.status == s }) {
                sb.appendLine("${r.key}")
                sb.appendLine("  A: ${r.a ?: "-"}")
                sb.appendLine("  B: ${r.b ?: "-"}")
            }
        }
    }
    if (a == null && b == null) {
        sb.appendLine()
        sb.appendLine("No files were loaded.")
    }
    return sb.toString()
}
